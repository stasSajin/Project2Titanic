# A/B Test Project
Please see the report on the following link.

The code used to perform all the calculations can be found in R Markdown file.
