# A/B Test Project
Please see the report on the following link: [A/B Project](https://cdn.rawgit.com/stasSajin/UdacityDataAnalystNanodegree/master/P7%20AB%20Testing/ABtest.html)

The code used to perform all the calculations can be found in R Markdown file.
